
protocol SomeProtocol {
    var x: Int { get set } // 일기, 쓰기 전용
    var y: Int { get } // 읽기전용
    static var tx: Int { get set }
    static func typeMethod()
    func random() -> Double
}

/*
 
특정 클래스와 관련없는 프로퍼티, 메서드 선언 집합
-함수(메서드) 정의는 없음
-기능이나 속성에 대한 설계도
-클래스(구조체, 열거형)에서 채택(adopt)하여 메서드를 구현해야 함

class class명: 부모명, 프로토콜명 {}
-부모가 있으면 부모 다음에 표시
class class명: 부모명, 프로토콜명1, 프로토콜명2 {}
class class명: 프로토콜명{}
-부모가 없으면 바로 표시 가능
class class명: 프로토콜명1, 프로토콜명2{}
클래스, 구조체, 열거형, extension에 프로토콜을 채택(adopt)할 수 있다.
-상속은 클래스만 가능


protocol 프로토콜명 {
    프로퍼티명
    메서드 선언
}

protocol 프로토콜명: 다른 프로토콜, 다른 프로토콜2 {
    //프로토콜은 다중 상속도 가능
}

protocol SomeProtocol {
    var x: Int { get set } // 일기, 쓰기 전용 // 프로퍼티
    var y: Int { get } // 읽기전용 // 프로퍼티
    static var tx: Int { get set } // 프로퍼티
    static func typeMethod() // 메서드
    func random() -> Double // 메서드
}


protocol Runnable {
    var x : Int = { get set }
    func run()
}

class Man : Runnable { // 사실 부모인지, 프로토콜인지 알 수 없지만 문맥상 파악, 채택 adopt
    var x : Int = 1 // 준수, conform
    func run(){print("달린다~")} // 준수, conform
}

//class Man에 x, run() 정의 없다면
type 'Man' does not conform to protocol 'Runnable'


protocol Runnable {
    var x : Int { get set }
    func run()
}

class Man : Runnable {
    var x : Int = 1
    func run(){
        print("달린다~")
    }
}

let han = han()
print(han.x)
han.run()

 */

git init






